# SPDX-FileCopyrightText: 2022-present Annie Ehler <annie.ehler.4@gmail.com>
#
# SPDX-License-Identifier: MIT
import sys

if __name__ == '__main__':
    from .cli import sleapyfaces

    sys.exit(sleapyfaces())
